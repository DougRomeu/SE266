<?php
/**
 * Created by PhpStorm.
 * User: Doug
 * Date: 12/11/2017
 * Time: 11:38 AM


 * Douglas Rose



 * Douglas Rose   12.11.2017
 *
 */
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Doug's Mailing List</title>
    <link href="https://fonts.googleapis.com/css?family=Monda" rel="stylesheet">
    <style>
        h3 {color: #bf0000;}
        table {border:1px solid black; text-align: center; position: relative;}
        td {border:1px solid black; padding: 10px;}
        th {border:1px solid black; color: #7d0000; padding: 5px;}
    </style>
</head>
<body>
<header>
    <nav>
        <a href="index.php">Home</a>
        <a href="view.php">View</a>
    </nav>
</header>
